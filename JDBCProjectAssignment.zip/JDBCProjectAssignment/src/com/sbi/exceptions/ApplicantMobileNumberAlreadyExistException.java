package com.sbi.exceptions;

public class ApplicantMobileNumberAlreadyExistException extends Exception{
	public ApplicantMobileNumberAlreadyExistException(String str) {
		super(str);
	}
}
