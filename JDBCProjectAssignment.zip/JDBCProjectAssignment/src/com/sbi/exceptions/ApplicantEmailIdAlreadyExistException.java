package com.sbi.exceptions;

public class ApplicantEmailIdAlreadyExistException extends Exception {
	public ApplicantEmailIdAlreadyExistException(String str) {
		super(str);
	}
}
