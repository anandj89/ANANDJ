package com.sbi.exceptions;

public class ApplicantDetailsNonExistException extends Exception {
	public ApplicantDetailsNonExistException(String str) {
		super(str);
	}
}
