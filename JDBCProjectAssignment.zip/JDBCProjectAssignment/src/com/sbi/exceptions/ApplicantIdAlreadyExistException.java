package com.sbi.exceptions;

public class ApplicantIdAlreadyExistException extends Exception {
	public ApplicantIdAlreadyExistException(String str) {
		super(str);
	}

}
