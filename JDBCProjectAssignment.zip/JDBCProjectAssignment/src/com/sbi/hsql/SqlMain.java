package com.sbi.hsql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Loaded");
			
			Connection conn=DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb","SA","");
			System.out.println("Connected to DB");
			
			Statement st=conn.createStatement();
			System.out.println("Created statement "+st);
			
			ResultSet rs=st.executeQuery("SELECT * FROM BANK_APPLICANT");
			System.out.println("SQL STATEMENT EXECUTED.");
			
			while(rs.next()) {
				System.out.println("APPLICATION ID:"+rs.getInt(1));
				System.out.println("APPLICATION ID:"+rs.getString(2));
				System.out.println("APPLICATION ID:"+rs.getString(3));
				System.out.println("APPLICATION ID:"+rs.getString(4));
				System.out.println("APPLICATION ID:"+rs.getString(5));
				System.out.println("APPLICATION ID:"+rs.getDate(6));
				System.out.println("-------------------------------");
				
				
				
				

			}
//			InsertTest it=new InsertTest();
//			it.InsertTest();
			UpdateTest ut=new UpdateTest();
			ut.UpdateTest();
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

}
