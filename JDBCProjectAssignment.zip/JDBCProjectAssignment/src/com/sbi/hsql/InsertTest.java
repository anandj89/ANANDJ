package com.sbi.hsql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Scanner;

import com.sbi.exceptions.ApplicantEmailIdAlreadyExistException;
import com.sbi.exceptions.ApplicantIdAlreadyExistException;
import com.sbi.exceptions.ApplicantMobileNumberAlreadyExistException;

public class InsertTest {

	public void InsertTest() throws SQLException
	{
		try
		{
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded.../registered....");
		
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to the db....");
			
			
			
			Statement st=conn.createStatement();
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter applicant ID");
			int id=sc.nextInt(); 
			
			System.out.println("Enter applicant name  \n");
			String name=sc.next();
			System.out.println("Enter email \n");
			String email=sc.next();
			System.out.println("Enter application address \n ");
			String address=sc.next();
			System.out.println("Enter mobNumber \n");
			String mobNumber=sc.next();

			ResultSet rs1=st.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_ID="+id);
//			ResultSet rs2=st.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_EMAIL_ADDRESS="+email);
//			ResultSet rs3=pst.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_MOBILE_NUMBER="+mobNumber);
			PreparedStatement pst = conn.prepareStatement("INSERT INTO BANK_APPLICANT VALUES (?,?,?,?,?,?) ");
			if(rs1.next()) {
				throw new ApplicantIdAlreadyExistException("Application ID Already Exist");		}
//			else if(rs2.next()) {
//				throw new ApplicantEmailIdAlreadyExistException("Email ID Already Exist");		}
//			else if(rs2.next()) {
//				throw new ApplicantMobileNumberAlreadyExistException("Email ID Already Exist");		}
			else {
			
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, email);
			pst.setString(4, address);
			pst.setString(5, mobNumber);
			
			Calendar cal = Calendar.getInstance();
			java.util.Date date = cal.getTime();
			
			java.sql.Date sqlDate= new java.sql.Date(date.getTime());
			pst.setDate(6,sqlDate);
			System.out.println("prepared statement is created..."+st);
			
			int row = pst.executeUpdate();
			System.out.println("row inserted..."+row);
			}

			st.close();
			conn.close();
			st.close();
			rs1.close();
//			rs2.close();
//			rs3.close();
			sc.close();
			
			System.out.println("DisConnected from the db....");
			
		}
//		catch(SQLException e) {
//			System.out.println("Some problem : "+e);
//		}
		catch(ApplicantIdAlreadyExistException e){
			System.out.println("Application Id Already Exist");
		}
//		catch(ApplicantEmailIdAlreadyExistException e){
//			System.out.println("Application Email Id Already Exist");
//		}
//		catch(ApplicantMobileNumberAlreadyExistException e){
//			System.out.println("Application Mobile Number Already Exist");
//		}
		
		
	}	}
