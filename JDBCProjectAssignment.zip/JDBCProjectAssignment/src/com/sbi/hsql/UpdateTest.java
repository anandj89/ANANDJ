package com.sbi.hsql;

   
import java.sql.*;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Scanner;

//import com.sbi.exceptions.ApplicantDetailsAlreadyExistException;
import com.sbi.exceptions.ApplicantDetailsNonExistException;
import com.sbi.exceptions.ApplicantIdAlreadyExistException;

public class UpdateTest {

	public void UpdateTest() throws SQLException {
		try
		{
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded.../registered....");
		
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to the db....");
			
			Statement st=conn.createStatement();
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter applicant ID");
			int id=sc.nextInt(); 
			
			System.out.println("Enter applicant name  \n");
			String name=sc.next();
//			System.out.println("Enter email \n");
//			String email=sc.next();
			System.out.println("Enter application address \n ");
			String address=sc.next();
//			System.out.println("Enter mobNumber \n");
//			String mobNumber=sc.next();
			ResultSet rs=st.executeQuery("SELECT APPLICANT_ID FROM PUBLIC.BANK_APPLICANT WHERE APPLICANT_NAME="+name+" OR APPLICANT_ADDRESS="+address+" OR APPLICANT_ID="+id);
			PreparedStatement pst = conn.prepareStatement("UPDATE BANK_APPLICANT SET APPLICANT_NAME=?, APPLICANT_ADDRESS=? WHERE APPLICANT_ID=?");
			if(rs.next()==false) {
				throw new ApplicantDetailsNonExistException("Application ID Already Exist");
				}
			else {
				
			pst.setString(1, name);
			pst.setString(2, address);
			pst.setInt(3, id);
			System.out.println("prepared statement is created..."+pst);
			pst.close();
			int row = pst.executeUpdate();
			System.out.println("row UPDATED..."+row);
			}
			
			conn.close();
			System.out.println("DisConnected from the db....");
			
		}
		catch(ApplicantDetailsNonExistException e) {
			System.out.println("APPLICATION DETAILS ENTERED ALREADY EXIST"+e);
		}
		
	}

}

