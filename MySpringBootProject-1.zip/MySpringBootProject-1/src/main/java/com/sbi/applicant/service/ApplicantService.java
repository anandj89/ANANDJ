package com.sbi.applicant.service;

import org.springframework.stereotype.Service;

import com.sbi.applicant.pojo.Applicant;


@Service
public interface ApplicantService {
	
	public void addApplicantService(Applicant app);

}
