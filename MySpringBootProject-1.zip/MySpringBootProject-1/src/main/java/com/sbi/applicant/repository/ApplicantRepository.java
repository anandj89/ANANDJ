package com.sbi.applicant.repository;

import com.sbi.applicant.pojo.Applicant;

public interface ApplicantRepository {

	
		void submitApplication(Applicant app);
}
