package com.sbi.applicant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.applicant.pojo.Applicant;
import com.sbi.applicant.service.ApplicantService;




@RestController
@RequestMapping("/applicant")
public class ApplicantController {
	@Autowired
	ApplicantService applicantService;
	
	
	@RequestMapping("/welcome")
	public String greet() {
		return "<h1>Welcome to Department Controller</h1>";
	}
	
	@PostMapping("/submitApp")
	public void submitTheApplication(@RequestBody Applicant applicant){
		 applicantService.addApplicantService(applicant);
	}
}
