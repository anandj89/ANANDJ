package com.sbi.applicant.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.applicant.pojo.Applicant;


@Repository("deptRepo")
public class ApplicantRepositoryImpl implements ApplicantRepository{
		
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Transactional
	public void submitApplication(Applicant app) {
		
		
			entityManager.persist(app);
			
		
	}
}
