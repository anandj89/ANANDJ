package com.sbi.applicant.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.type.LocalDateType;

@Entity
@Table(name="")
public class Applicant {
	
	@Id
	@Column(name="")
	@GeneratedValue
	int applicantId;
	
	@Column(name="")
	String title;
	
	@Column(name="")
	String firstName;
	
	@Column(name="")
	String fmiddleName;
	
	@Column(name="")
	String lastName;
	
	@Column(name="")
	String fatherName;
	
	@Column(name="")
	String motherName;
	
	@Column(name="")
	String maritalStatus;
	
	@Column(name="")
	LocalDate dob;
	
	@Column(name="")
	String gender;
	
	@Column(name="")
	String addressLine1;
	
	@Column(name="")
	String addressLine2;
	
	@Column(name="")
	String addressLine3;
	
	@Column(name="")
	int pinCode;
	
	@Column(name="")
	String mobileNumber;
	
	@Column(name="")
	String panCard;
	
	@Column(name="")
	String aadhaar;
	
	@Column(name="")
	String photoIdType;
	
	@Column(name="")
	String photoIdNumber;
	
	@Column(name="")
	String addressIdType;
	
	@Column(name="")
	String addressIdNumber;
	
	@Column(name="")
	String nomineeName;
	
	@Column(name="")
	String relationship;
	
	@Column(name="")
	LocalDate nomineeDob;
	
	@Column(name="")
	String guardianName;
	
	@Column(name="")
	String nomineeGuardianRelation;
	
	@Column(name="")
	String guardianAddress;
	
	@Column(name="")
	String religion;
	
	@Column(name="")
	String educationalQualifications;
	
	@Column(name="")
	String annualIncome;

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFmiddleName() {
		return fmiddleName;
	}

	public void setFmiddleName(String fmiddleName) {
		this.fmiddleName = fmiddleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getAadhaar() {
		return aadhaar;
	}

	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}

	public String getPhotoIdType() {
		return photoIdType;
	}

	public void setPhotoIdType(String photoIdType) {
		this.photoIdType = photoIdType;
	}

	public String getPhotoIdNumber() {
		return photoIdNumber;
	}

	public void setPhotoIdNumber(String photoIdNumber) {
		this.photoIdNumber = photoIdNumber;
	}

	public String getAddressIdType() {
		return addressIdType;
	}

	public void setAddressIdType(String addressIdType) {
		this.addressIdType = addressIdType;
	}

	public String getAddressIdNumber() {
		return addressIdNumber;
	}

	public void setAddressIdNumber(String addressIdNumber) {
		this.addressIdNumber = addressIdNumber;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public LocalDate getNomineeDob() {
		return nomineeDob;
	}

	public void setNomineeDob(LocalDate nomineeDob) {
		this.nomineeDob = nomineeDob;
	}

	public String getGuardianName() {
		return guardianName;
	}

	public void setGuardianName(String guardianName) {
		this.guardianName = guardianName;
	}

	public String getNomineeGuardianRelation() {
		return nomineeGuardianRelation;
	}

	public void setNomineeGuardianRelation(String nomineeGuardianRelation) {
		this.nomineeGuardianRelation = nomineeGuardianRelation;
	}

	public String getGuardianAddress() {
		return guardianAddress;
	}

	public void setGuardianAddress(String guardianAddress) {
		this.guardianAddress = guardianAddress;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getEducationalQualifications() {
		return educationalQualifications;
	}

	public void setEducationalQualifications(String educationalQualifications) {
		this.educationalQualifications = educationalQualifications;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	
	
	
	
	
}
