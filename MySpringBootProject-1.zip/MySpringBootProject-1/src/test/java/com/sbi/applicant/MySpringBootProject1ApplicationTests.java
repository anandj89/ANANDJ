package com.sbi.applicant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
