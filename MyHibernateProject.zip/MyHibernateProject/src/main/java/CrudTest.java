import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class CrudTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Trying to read persistence.xml file...");

		// 3
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");

		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager created....");

		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction created....");

		System.out.println("Trying to create record.....");

//		Flight theFlight= new Flight();
//		theFlight.setFlightNumber(102);
//		theFlight.setFlightName("Vistara");
//		theFlight.setFlightSource("TVM");
//		theFlight.setFlightDestination("Chennai");
//		theFlight.setFlightTicketCost(5000);
//		theFlight.setNumberOfPassengers(250);
//		theFlight.setFlightDepartureFromSource(LocalDateTime.now());
//		theFlight.setFlightArrivalAtDestination(LocalDateTime.now());
//		
//		et.begin();
//		em.persist(theFlight);									//insert
//		et.commit();
		System.out.println("=================");
		
		
		
//		et.begin();
//			Flight f = em.find(Flight.class, 100);		
//			f.setFlightDestination("USA");
//			em.merge(f);											//update
//		et.commit();

		System.out.println("Created the record.....");

		et.begin();
		Flight fl = em.find(Flight.class, 100); 					// Retrieve one row
		System.out.println(fl.getFlightName());
		System.out.println(fl.getFlightSource());
		System.out.println(fl.getFlightDestination());
		et.commit();
		
		
		et.begin();
		Flight ft = em.find(Flight.class, 0);
		em.remove(ft);												 // Delete a row
		et.commit();

		Query q=em.createNativeQuery("Select * from Flight_info",Flight.class);
		List <Flight> f1=(List<Flight>) q.getResultList();
		for(Flight list:f1)
		{
		System.out.println("Flight Number is.."+list.getFlightnumber());
		System.out.println("Flight Name is.."+list.getFlightName());
		System.out.println("======================================");
		
		}
	}

}