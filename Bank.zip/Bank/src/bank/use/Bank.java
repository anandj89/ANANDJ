package bank.use;
//import java.time.LocalDate;

import bank.account.BankAccount;
import bank.account.CurrentAccount;
import bank.account.FixedDepositAccount;
import bank.account.SavingsAccount;
import bank.account.Transactions;
import bank.exceptions.AccountBalanceNegativeException;
import bank.exceptions.AccountNameNullException;
import bank.exceptions.AccountNumberExceededException;

public class Bank {
	public static void main(String[] args) { //throws AccountNumberExceededException, AccountNameNullException, AccountBalanceNegativeException {
		
		BankAccount baAccObj1 = null;
		try {
			 baAccObj1 = new BankAccount(101, "Jack",50000);
			BankAccount baAccObj2 = new BankAccount(1023, "Anand",50000);
		} catch (AccountNumberExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountBalanceNegativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("-------------");

		SavingsAccount savAccObj2 = null;
		try {
			savAccObj2 = new SavingsAccount(102,"Jane",90000,3.5);
		} catch (AccountNumberExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountBalanceNegativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("-------------");

		FixedDepositAccount fdAccObj3 = null;
		try {
			fdAccObj3 = new FixedDepositAccount(101,"Julie",90000,7.5,5);
		} catch (AccountNumberExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountBalanceNegativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("-------------");

		CurrentAccount caAccObj4 = null;
		try {
			caAccObj4 = new CurrentAccount(101,"Jude",90000,7.5);
		} catch (AccountNumberExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountBalanceNegativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		baAccObj1.printBankAccount();
		System.out.println("-------------");
		
		savAccObj2.printBankAccount();
		double si = savAccObj2.calculateSimpleInterest();
		System.out.println("simple interest : "+si);
		
		System.out.println("-------------");
		fdAccObj3.printBankAccount();
		double ma = fdAccObj3.calculateMaturityAmount();
		System.out.println("maturity amount : "+ma);
		
		savAccObj2.printBankAccount();
		double eligibility=caAccObj4.oDLimit();
		double od = caAccObj4.monthlyInterest();
        System.out.println("OD eligibility is : "+eligibility);
		System.out.println("monthly OD Interest is  interest : "+od);
		
		
		Transactions t = null;
		try {
			t = new BankAccount(101, "Jack",50000);
		} catch (AccountNumberExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountBalanceNegativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t.printBankAccount();
		t.deposit(5000);
		t.deposit(6000);
		t.withdraw(2000);
		t.printBankAccount();
		
		
		
	}
}

//making the data member as private
// and allowing this data via accessible functions




