package bank.account;

import bank.exceptions.AccountBalanceNegativeException;
import bank.exceptions.AccountNameNullException;
import bank.exceptions.AccountNumberExceededException;

public class FixedDepositAccount extends SavingsAccount
{
	//DATA MEMBER
	private int tenure;
	
	public FixedDepositAccount(int x, String y, double z, double r, int t) throws AccountNumberExceededException, AccountNameNullException, AccountBalanceNegativeException
	{
		super(x,y,z,r); //invoke the ctor of the super class
		System.out.println("FixedDepositAccount(int,String,double,double,int)...constructor invoked....");
		
		if(t<0) {
			throw new RuntimeException("Fixed Deposit Account tenure cannot be in negative...terminating..");
		}
		else 
			tenure=t;
	}
	
	//accessor 
	public void printBankAccount() 
	{
		super.printBankAccount();
		System.out.println("Fixed Tenure    : "+tenure);
		System.out.println("-----------------------");
	}
	
	public double calculateMaturityAmount() {
		double x = Math.pow( (1+rateOfInterest/100), tenure);
		double y = accountBalance * x;
		return y;
	}
}