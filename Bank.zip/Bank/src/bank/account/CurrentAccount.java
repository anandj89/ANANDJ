package bank.account;

import bank.exceptions.AccountBalanceNegativeException;
import bank.exceptions.AccountNameNullException;
import bank.exceptions.AccountNumberExceededException;

public class CurrentAccount extends BankAccount  {
	double rateOfOD;

	public CurrentAccount(int a, String b, int c, double d) throws AccountNumberExceededException, AccountNameNullException, AccountBalanceNegativeException {
		super(a, b, c);
		System.out.println("Current Acc constructor invoked.....");
		if (d < 0) {
			throw new RuntimeException("rate cannot be in negative");
		} else
			rateOfOD = d;
	}

	public void printBankAccount() {
		super.printBankAccount();
		System.out.println("rate of overdraft is " + rateOfOD);
	}

	public double oDLimit() {
		double bal = super.getBalance();
		double eligibility = (75.0 / 100) * bal;
		return eligibility;

	}

	public double monthlyInterest() {
		double e = oDLimit();
		double mI = (e * rateOfOD * 1.0) / 100;
		return mI;
	}
}