package bank.account;

import bank.exceptions.AccountBalanceNegativeException;
import bank.exceptions.AccountNameNullException;
import bank.exceptions.AccountNumberExceededException;

//import java.time.LocalDate;

public class BankAccount extends Thread implements Transactions
{
	//DATA MEMBER
	private int accountNumber; //FIELD
	private String accountHolderName; //FIELD
	protected double accountBalance; //FIELD
	//private LocalDate accountOpeningDate;
	
	public BankAccount(int x, String y, double z) throws AccountNumberExceededException, AccountNameNullException, AccountBalanceNegativeException
	{
		System.out.println("BankAccount(int,String,double)...constructor invoked....");
		
		if(x>999) {
			throw new AccountNumberExceededException("Account number cannot be more than 1000...terminating..");
		}
		else
			accountNumber=x;
		
		if(y==null) {
			throw new AccountNameNullException("Account holder name cannot be null...terminating..");
		}
		else
			accountHolderName=y;
		
		if(z<0) {
			//RuntimeException r = new RuntimeException("some problem.....");
			//throw r;
			throw new AccountBalanceNegativeException("Account Balance cannot be in negative...terminating..");
		}
		else
			accountBalance=z;
	}
	
	//accessor 
	public void printBankAccount() 
	{
		System.out.println("Account Number  : "+accountNumber);
		System.out.println("Account HName   : "+accountHolderName);
		System.out.println("Account Balance : "+accountBalance);
		System.out.println("-----------------------");
	}
	public double withdraw(double amountToWithdraw) {
		if(amountToWithdraw > accountBalance) {
			throw new RuntimeException("Insufficient funds....");
		}
		System.out.println("Withdraw in progresss..."+amountToWithdraw);
		accountBalance = accountBalance - amountToWithdraw;
		System.out.println("Withdraw is done...");
		return accountBalance;
	}
	
	public double deposit(double amountToDeposit) {
		if(amountToDeposit > 50000) {
			throw new RuntimeException("Please provide the PAN OR Form60");
		}
		System.out.println("Deposit in progresss..."+amountToDeposit);
		accountBalance = accountBalance + amountToDeposit;
		System.out.println("Deposit is done...");
		return accountBalance;
	}
	
	public double getBalance() { //accessor
		return accountBalance;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}