package bank.account;

import bank.exceptions.AccountBalanceNegativeException;
import bank.exceptions.AccountNameNullException;
import bank.exceptions.AccountNumberExceededException;

public class SavingsAccount extends BankAccount 
{
	//DATA MEMBER
	protected double rateOfInterest;
	
	public SavingsAccount(int x, String y, double z, double r) throws AccountNumberExceededException, AccountNameNullException, AccountBalanceNegativeException
	{
		super(x,y,z); //invoke the ctor of the super class
		System.out.println("SavingsAccount(int,String,double,double)...constructor invoked....");
		
		if(r<0) {
			throw new RuntimeException("Account rate cannot be in negative...terminating..");
		}
		else 
			rateOfInterest=r;
	}
	
	//accessor 
	public void printBankAccount() 
	{
		super.printBankAccount();
		System.out.println("Account ROI     : "+rateOfInterest);
		System.out.println("-----------------------");
	}
	
	public double calculateSimpleInterest() {
		return (super.accountBalance*1*rateOfInterest)/100;
	}
}
