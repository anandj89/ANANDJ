package bank.account;

public interface Transactions {
	double getBalance();
	double deposit(double amountToDeposit);
	double withdraw(double amountToWithdraw);
	public void printBankAccount();
}
