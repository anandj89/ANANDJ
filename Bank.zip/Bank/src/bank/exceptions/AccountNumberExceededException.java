package bank.exceptions;

public class AccountNumberExceededException extends Exception {
	
	public AccountNumberExceededException(String str) {
		super(str);
	}

}