package bank.exceptions;

public class AccountNameNullException extends Exception {
	public AccountNameNullException(String str) {
		super(str);
	}
}
