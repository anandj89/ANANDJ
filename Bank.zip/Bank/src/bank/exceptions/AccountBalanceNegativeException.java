package bank.exceptions;

public class AccountBalanceNegativeException extends Exception {
	public AccountBalanceNegativeException(String str) {
		super(str);
	}
}
