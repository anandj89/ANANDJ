package com.sbi.livingbeing.animal;

public interface Reproduction {
	
	public void reproduce();
}
