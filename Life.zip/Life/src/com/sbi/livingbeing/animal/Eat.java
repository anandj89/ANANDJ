package com.sbi.livingbeing.animal;

public interface Eat {
	
	public void eat();
}
