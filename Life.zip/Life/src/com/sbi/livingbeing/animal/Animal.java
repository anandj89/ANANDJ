package com.sbi.livingbeing.animal;

import com.sbi.livingbeing.Living;
import com.sbi.livingbeing.LivingBeing;

public class Animal extends LivingBeing implements Eat, Sleep, Reproduction {

	Heart h = new Heart();

	public void alive() {
		Living l=h.pump();
		l=new Animal();
		l.breath();
		System.out.println("Animal is living");
		
		
	}

	@Override
	public void reproduce() {
		// TODO Auto-generated method stub
		System.out.println("Animal can reproduce");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("Animal can sleep");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Animal eats to iive");
	}
	
	public void breath() {
		// TODO Auto-generated method stub
		System.out.println("Animal is breathing");
	}
}
