package com.sbi.livingbeing.animal;

import com.sbi.livingbeing.Living;

public class Heart {
		
		public Living pump() {
			// TODO Auto-generated method stub
			Living live=new Animal();
			System.out.println("Heart is still pumping");
			return live;
		}
		
}
