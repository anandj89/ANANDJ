package com.sbi.livingbeing.animal.human;

import java.util.Scanner;

public class Employee extends Student {
	String employee;
	
	public Employee(){
		
	
	}
	
	
	
	
	public void selection(Result r) {
		Teacher t=new Teacher();
		
		if(t.getMarks()>90) {
			System.out.println("Student is selected as the employee");
		}
		else {
			System.out.println("SORRY..BUT DONT GIVE UP");
			
		}
	}
	public void work() {
		System.out.println("Employee starts working");
	}
	
	
	
}
