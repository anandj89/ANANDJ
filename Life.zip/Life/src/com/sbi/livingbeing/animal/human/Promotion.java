package com.sbi.livingbeing.animal.human;

public interface Promotion {
	public void PromotionExercise(Employee e);
}
