package com.sbi.livingbeing.animal.human;

public interface Policies {
	
	public void decisionMaking();
	
}
