package com.sbi.livingbeing.animal.human;

import com.sbi.livingbeing.animal.*;
public class Human extends Mammal implements Thought {

	@Override
	public void think() {
		// TODO Auto-generated method stub
		System.out.println("humans think");
	}

	

	
	
	

}
