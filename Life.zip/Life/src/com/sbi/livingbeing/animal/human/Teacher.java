package com.sbi.livingbeing.animal.human;

import java.util.Scanner;

public class Teacher extends Human implements Teaching{

	@Override
	public void teach() {
		// TODO Auto-generated method stub
		System.out.println("Teacher teaches");
	}
	public void setExam(Result r) {
		
		int marks=r.getMarks();
		r.getResult(marks);
		
	}
	public final int getMarks() {
		Scanner  sc =new Scanner(System.in);
		System.out.println("Enter the marks");
		int marks=sc.nextInt();
		
		return marks;
	}
	public final void getResult(int marks) {
		if(marks>=90) {
			String result="A GRADE";
			System.out.println(result);
		}
		else if(marks<900&& marks>=75) {
			String result="B GRADE";
			System.out.println(result);
		}
		else if(marks<75&& marks>=60) {
			String result="C GRADE";
			System.out.println(result);
		}
		else if(marks<60&& marks>=40) {
			String result="D GRADE";
			System.out.println(result);
		}
		else if(marks<40&& marks>=0) {
			String result="FAILED";
			System.out.println(result);
		}
	}
}
