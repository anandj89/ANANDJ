package com.sbi.livingbeing.animal.human;

public interface Result {
	public int getMarks(); 
	public void getResult(int marks);
}
