package com.sbi.livingbeing.animal.human;

import java.util.Scanner;

public class Manager extends Employee implements Promotion {

	

String manager;
	
	 public Manager(){
		
	
	}
	 
	 public void manage(){
		 System.out.println("Manager take cares of the management and supervision");
	 }
	@Override
	public void PromotionExercise(Employee e) {
		// TODO Auto-generated method stub
		
		 Employee e1 = new Employee();
		 
		int marks = 	getCDSScore(e1);
		if (marks > 90) {
			System.out.println("Employee has been promoted");
		} else
			System.out.println("Better luck next time");
		  //  System.exit(0);
	}
	
	public final int getCDSScore(Employee e) {
		Scanner sc = new Scanner(System.in);
		System.out.println("MANAGER HAS TO ENTER EMPLOYEE'S CDS SCORE95");
		System.out.println("ENTER THE CDS SCORE OF THE EMPLOYEE");
		int m = sc.nextInt();
		
		return m;
	}

}

 class CDSScore {

	}