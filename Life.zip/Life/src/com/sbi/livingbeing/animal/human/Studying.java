package com.sbi.livingbeing.animal.human;

public interface Studying extends Result{
	public void study();
}
