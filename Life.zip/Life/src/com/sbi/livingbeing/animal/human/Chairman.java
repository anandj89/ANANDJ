package com.sbi.livingbeing.animal.human;

import java.util.Scanner;

public class Chairman extends Manager implements Policies {
	
	
	
	public void PromotionExercise(Manager m) {
		// TODO Auto-generated method stub
		
		Manager m1 = new Manager();
		int marks = getCDSScore(m1);
		if (marks > 90) {
			System.out.println("Manager has been promoted");
		} else
			System.out.println("Better luck next time");
	}
	public final int getCDSScore(Manager m)  {
		Scanner scr = new Scanner(System.in);
		System.out.println("CHAIRMAN HAS TO ENTER MANAGER.S ");
		System.out.println("ENTER THE CDS SCORE OF MANAGER");
		int s = scr.nextInt();
		
		return s;
	}
	@Override
	public void decisionMaking() {
		// TODO Auto-generated method stub
		
	}
}
