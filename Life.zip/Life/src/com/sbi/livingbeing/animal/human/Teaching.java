package com.sbi.livingbeing.animal.human;

public interface Teaching extends Result {
	public void teach();
}
