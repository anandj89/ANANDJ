package com.sbi.livingbeing.animal.human;

public class Student extends Human implements Studying{

	
	public void think() {
		// TODO Auto-generated method stub
		System.out.println("Since students are humans students think");
	}

	
	//Thought t1=new Teacher();
	//Thought t2=new Student();
	
	public Result study(Thought t,Thought t3) {
		// TODO Auto-generated method stub
		System.out.println("Student adding his thoughts with those of teachers and waiting for result");
		Result r=new Teacher();
		return r;
	}


	@Override
	public void study() {
		// TODO Auto-generated method stub

			System.out.println("Students Study");
	

	}


	@Override
	public int getMarks() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public void getResult(int marks) {
		// TODO Auto-generated method stub
		
	}}
