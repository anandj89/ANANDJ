package com.sbi.livingbeing.animal.human;

public interface Thought {
	public void think();
}
