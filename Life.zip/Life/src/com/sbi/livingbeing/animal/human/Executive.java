package com.sbi.livingbeing.animal.human;

public class Executive {

}
