package com.sbi.livingbeing.animal;

public class Mammal extends Animal {
	
	

public void reproduce(Reproduction r) {
	System.out.println("Mammals can give birth");
}
}