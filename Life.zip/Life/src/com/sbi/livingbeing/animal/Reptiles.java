package com.sbi.livingbeing.animal;

public class Reptiles extends Animal {

}
