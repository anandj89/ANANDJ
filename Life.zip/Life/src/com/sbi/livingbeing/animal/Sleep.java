package com.sbi.livingbeing.animal;

public interface Sleep {
	public void sleep();
}
