package com.sbi.livingbeing;

public class LivingBeing implements Living,Dying {

	

	@Override
	public void dead() {
		// TODO Auto-generated method stub
		System.out.println("Living Being is dead");
	}

	@Override
	public void alive() {
		// TODO Auto-generated method stub
		System.out.println("Living Being is alive");
	}

	@Override
	public void breath() {
		// TODO Auto-generated method stub
		System.out.println("Living being is breathing");
	}
	
	

}
