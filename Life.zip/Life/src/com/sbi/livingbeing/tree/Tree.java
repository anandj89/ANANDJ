package com.sbi.livingbeing.tree;

import com.sbi.livingbeing.LivingBeing;

public class Tree extends LivingBeing implements Planting,Growing {

	@Override
	public void fertilize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void water() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void plant() {
		// TODO Auto-generated method stub
		
	}

}
interface Planting{
	void plant();
}
interface Growing {
	void fertilize();
	void water();
}