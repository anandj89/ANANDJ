package com.sbi.livingbeing;

public interface Dying {

	public void dead();
}
