package com.sbi.livingbeing;

public interface Living {
	
	public void alive();
	public void breath();
}
