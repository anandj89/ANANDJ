package com.sbi.use;

import com.sbi.livingbeing.*;
import com.sbi.livingbeing.animal.*;
import com.sbi.livingbeing.animal.human.Chairman;
import com.sbi.livingbeing.animal.human.Employee;
import com.sbi.livingbeing.animal.human.Human;
import com.sbi.livingbeing.animal.human.Manager;
import com.sbi.livingbeing.animal.human.Result;
import com.sbi.livingbeing.animal.human.Student;
import com.sbi.livingbeing.animal.human.Teacher;

public class Life {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a=new Animal();
		a.alive();
		
		Student s=new Student();
		Teacher t=new Teacher();
		s.think();
		s.study();
		t.teach();
		s.study(s, t);
		
		Result r=t;
		int b=r.getMarks();
		
		r.getResult(b);
		
		
		
		Employee e=new Employee();
		e.selection(r);
		e.work();
		
		Manager m=new Manager();
		m.PromotionExercise(e);
		m.manage();
		
		Chairman ch=new Chairman();
		ch.PromotionExercise(m);
	
		Eat eat=new Chairman();
		eat.eat();
		
		
		Dying d=new LivingBeing();
		
	}

}
