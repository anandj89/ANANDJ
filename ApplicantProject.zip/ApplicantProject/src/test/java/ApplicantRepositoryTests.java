import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.applicant.pojo.Applicant;
import com.sbi.applicant.repository.ApplicantRepositoryImpl;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicantRepositoryTests {
	@Autowired
	ApplicantRepositoryImpl applicantRepository; 
	
	
	EntityManager entityManager;
	Applicant app=new Applicant();
	
	@Test
	void submitAppl() {
		app.setTitle("mr");
		app.setFirstName("Anand");
		
		applicantRepository.submitApplication(app);
			
		
	}

}






