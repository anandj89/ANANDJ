package com.sbi.applicant.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.applicant.pojo.Applicant;


@Service
public interface ApplicantService {
	
	List<Applicant> fetchAllApplicantService();
	public void addApplicantService(Applicant app);

}
