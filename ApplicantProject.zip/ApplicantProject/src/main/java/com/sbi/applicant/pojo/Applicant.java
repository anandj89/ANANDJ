package com.sbi.applicant.pojo;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="applicant")
public class Applicant {
	
	@Id
	@Column(name="appid")
	@GeneratedValue
	int applicantId;
	
	
	
	@Column(name="title")
	String title;
	
	@Column(name="firstName")
	String firstName;
	
	@Column(name="middleName")
	String middleName;
	
	@Column(name="lastName")
	String lastName;
	
	@Column(name="maidenName")
	String maidenName;
	

	@Column(name="dateOfBirth")
	Date dob;

	@Column(name="gender")
	String gender;
	
	@Column(name="placeOfBirth")
	String placeOfBirth;
	
	@Column(name="countryOfBirth")
	String countryOfBirth;
	
	@Column(name="maritalStatus")
	String maritalStatus;
	
	@Column(name="aadharNum")
	String aadharNum;
	
	@Column(name="mobile")
	String mobileNumber;
	
	@Column(name="emailId")
	String emailId;
	
	@Column(name="fatherName")
	String fatherName;
	
	@Column(name="motherName")
	String motherName;
	
	@Column(name="spouseName")
	String spouseName;
	
	@Column(name="idType")
	String idType;
	
	@Column(name="idNumber")
	String idNumber;
	
	@Column(name="issuedOn")
	Date issuedOn;
	
	@Column(name="panCard")
	String panCard;
	
	@Column(name="nameOnPAN")
	String nameonPAN;

	
	@Column(name="addressLine1")
	String addressLine1;
	
	@Column(name="addressLine2")
	String addressLine2;
	
	@Column(name="city")
	String city;
	
	@Column(name="state")
	String state;
	
	@Column(name="pinCode")
	int pinCode;
	
	@Column(name="country")
	String country;
	
	@Column(name="educationalQualification")
	String educationalQualification;
	
	@Column(name="occupation")
	String occupation;
	
	@Column(name="annualIncome")
	int annualIncome;
	
	@Column(name="religion")
	String religion;
	
	
	@Column(name="inbRights")
	String inbRights;	
	
	@Column(name="smsAlerts")
	String smsAlerts;	
	
	@Column(name="chequeBook")
	String chequeBook;	
	
	@Column(name="debitCard")
	String debitCard;
	
	@Column(name="nameOnCard")
	String nameOnCard;
	
	@Column(name="nomineeReq")
	String nomineeReq;
	
	@Column(name="nomineeName")
	String nomineeName;
	
	@Column(name="nomineeRel")
	String nomineeRel;
		
	@Column(name="nomineeAddressLine1 ")
	String nomineeAddressLine1 ;
	
	@Column(name="nomineeAddressLine2 ")
	String nomineeAddressLine2 ;

	@Column(name="nomineeDOB")
	Date nomineeDOB;
	
	@Column(name="nomineeState ")
	String nomineeState ;
	
	@Column(name="nomineePincode ")
	String nomineePincode ;
	
	@Column(name="nomineeCountry ")
	String nomineeCountry ;
	
	@Column(name="guardianName")
	String guardianName;
	
	@Column(name="guardianRel ")
	String GuardianRel;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMaidenName() {
		return maidenName;
	}

	public void setMaidenName(String maidenName) {
		this.maidenName = maidenName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getAadharNum() {
		return aadharNum;
	}

	public void setAadharNum(String aadharNum) {
		this.aadharNum = aadharNum;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public Date getIssuedOn() {
		return issuedOn;
	}

	public void setIssuedOn(Date issueOn) {
		this.issuedOn = issueOn;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getNameonPAN() {
		return nameonPAN;
	}

	public void setNameonPAN(String nameonPAN) {
		this.nameonPAN = nameonPAN;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getstate() {
		return state;
	}

	public void setstate(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEducationalQualification() {
		return educationalQualification;
	}

	public void setEducationalQualification(String educationalQualification) {
		this.educationalQualification = educationalQualification;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public int getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getInbRights() {
		return inbRights;
	}

	public void setInbRights(String inbRights) {
		this.inbRights = inbRights;
	}

	public String getSmsAlerts() {
		return smsAlerts;
	}

	public void setSmsAlerts(String smsAlerts) {
		this.smsAlerts = smsAlerts;
	}

	public String getChequeBook() {
		return chequeBook;
	}

	public void setChequeBook(String chequeBook) {
		this.chequeBook = chequeBook;
	}

	public String getDebitCard() {
		return debitCard;
	}

	public void setDebitCard(String debitCard) {
		this.debitCard = debitCard;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public String getNomineeReq() {
		return nomineeReq;
	}

	public void setNomineeReq(String nomineeReq) {
		this.nomineeReq = nomineeReq;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getNomineeRel() {
		return nomineeRel;
	}

	public void setNomineeRel(String nomineeRel) {
		this.nomineeRel = nomineeRel;
	}

	public String getNomineeAddressLine1() {
		return nomineeAddressLine1;
	}

	public void setNomineeAddressLine1(String nomineeAddressLine1) {
		this.nomineeAddressLine1 = nomineeAddressLine1;
	}

	public String getNomineeAddressLine2() {
		return nomineeAddressLine2;
	}

	public void setNomineeAddressLine2(String nomineeAddressLine2) {
		this.nomineeAddressLine2 = nomineeAddressLine2;
	}

	public Date getNomineeDOB() {
		return nomineeDOB;
	}

	public void setNomineeDOB(Date nomineeDOB) {
		this.nomineeDOB = nomineeDOB;
	}

	public String getNomineeState() {
		return nomineeState;
	}

	public void setNomineeState(String nomineeState) {
		this.nomineeState = nomineeState;
	}

	public String getNomineePincode() {
		return nomineePincode;
	}

	public void setNomineePincode(String nomineePincode) {
		this.nomineePincode = nomineePincode;
	}

	public String getNomineeCountry() {
		return nomineeCountry;
	}

	public void setNomineeCountry(String nomineeCountry) {
		this.nomineeCountry = nomineeCountry;
	}

	public String getGuardianName() {
		return guardianName;
	}

	public void setGuardianName(String guardianName) {
		this.guardianName = guardianName;
	}

	public String getGuardianRel() {
		return GuardianRel;
	}

	public void setGuardianRel(String guardianRel) {
		GuardianRel = guardianRel;
	}

	public int getApplicantId() {
		return applicantId;
	}
	
	/*
	 * @Column(name="appliedOn ") Date appliedOn ;
	 * 
	 * @Column(name="statusChangedOn ") Date statusChangedOn ;
	 * 
	 * @Column(name="status") Date status;
	 */
	
	
		
	
}
