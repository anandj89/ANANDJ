package com.sbi.applicant.service;

import org.springframework.stereotype.Service;

@Service
public interface MailService {
	public void sendMail(String info,String email);
}
