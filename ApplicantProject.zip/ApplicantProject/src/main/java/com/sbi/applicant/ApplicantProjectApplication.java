package com.sbi.applicant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicantProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicantProjectApplication.class, args);
	}

}
