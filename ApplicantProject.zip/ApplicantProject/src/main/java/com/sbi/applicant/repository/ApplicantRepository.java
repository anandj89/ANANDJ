package com.sbi.applicant.repository;

import java.util.List;

import com.sbi.applicant.pojo.Applicant;

public interface ApplicantRepository {

		public List<Applicant> getAllApplicant();
		void submitApplication(Applicant app);
}
