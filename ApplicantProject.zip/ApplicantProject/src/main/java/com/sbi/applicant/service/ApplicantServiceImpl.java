package com.sbi.applicant.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.applicant.pojo.Applicant;
import com.sbi.applicant.repository.ApplicantRepository;


@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired // 3
	ApplicantRepository applicantRepository;

	public void addApplicantService(Applicant app) {

		applicantRepository.submitApplication(app);
	}

	@Override
	public List<Applicant> fetchAllApplicantService() {
		List<Applicant> applList= applicantRepository.getAllApplicant();
		return applList;
	}
}
