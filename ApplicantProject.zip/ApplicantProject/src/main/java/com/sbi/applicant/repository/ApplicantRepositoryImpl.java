package com.sbi.applicant.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.applicant.pojo.Applicant;




@Repository("applicantRepo")
public class ApplicantRepositoryImpl implements ApplicantRepository{
		
	@PersistenceContext
	EntityManager entityManager;
	
	public List<Applicant> getAllApplicant() {
		List<Applicant> applList = null;
		TypedQuery<Applicant> query = entityManager.createQuery("from Applicant", Applicant.class);
		return applList;
	}	
	
	@Transactional
	public void submitApplication(Applicant app) {
				
			entityManager.persist(app);
			
		
	}
}
