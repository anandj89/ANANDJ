import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-test2',
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.css']
})
export class Test2Component implements OnInit {

  constructor() { }

  userName:any;
  password:any;
  userAge:any;
  userAddress:any;


  dataGroup:any;
  ngOnInit(): void {

    this.dataGroup=new FormGroup({
      a:new FormControl(""),
      b:new FormControl(""),
      c:new FormControl(""),
      d:new FormControl(""),
      
  })
  }
  onClickSubmit(result:any){
    this.userName=result.a;
    this.password=result.b;
    this.userAge=result.c;
    this.userAddress=result.d;
  }

}
