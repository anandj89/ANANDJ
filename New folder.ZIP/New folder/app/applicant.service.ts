import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Applicant } from './applicant/Applicant';

@Injectable({
  providedIn: 'root'
})
export class ApplicantService {

  constructor(private myHttp:HttpClient) { }
  
    addApplicant(applicant:Applicant):Observable<string>{
      console.log('add Applicant() invoked......');
      return this.myHttp.post<string>("http://localhost:8080/submitApp",applicant,{responseType:'text' as'json'});
    }
}

