import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserPhoto } from './user-photo-upload/UserPhotoUpload';

@Injectable({
  providedIn: 'root'
})
export class UserPhotoUploadService {

  constructor(private myHttp: HttpClient) { }
  loadAllUserPhotoService() : Observable<UserPhoto[]> {
    return this.myHttp.get<UserPhoto[]>("https://jsonplaceholder.typicode.com/photos")
  }
}
