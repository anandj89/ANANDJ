import { TestBed } from '@angular/core/testing';

import { UserPhotoUploadService } from './user-photo-upload.service';

describe('UserPhotoUploadService', () => {
  let service: UserPhotoUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserPhotoUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
