import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user-details',
  templateUrl: './add-user-details.component.html',
  styleUrls: ['./add-user-details.component.css']
})
export class AddUserDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
