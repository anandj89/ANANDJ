import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-employees',
  templateUrl: './our-employees.component.html',
  styleUrls: ['./our-employees.component.css']
})
export class OurEmployeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
