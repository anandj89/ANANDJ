import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../login-me/User';

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {
  userObj:User=new User();
  anyObject:any;
  constructor(private router:Router) { }

  ngOnInit(): void {
    this.anyObject=sessionStorage.getItem("x");
    this.userObj=JSON.parse(this.anyObject);
  }
  logOutThisUser(){
    this.router.navigate(['/login'])
  }
}
