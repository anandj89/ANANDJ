export class GeoLocation {
    lat! :string;
    lng! :string;
}