import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { LoginMeComponent } from './login-me/login-me.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import {MatDatepickerModule} from '@angular/material/datepicker';

const routes: Routes = [
  {
      path:'about',
      children:[
        {path:'',component:AboutComponent},
        {path:'our-emps',component:OurEmployeesComponent},
        {path:'our-comp',component:OurCompanyComponent},
      ]
  },

 
 
  {path:'login',component:LoginMeComponent},
  {path:'register',component:RegisterComponent},
  {path:'dashboard',component:DashBoardComponent},
  {path:'admin-dashboard',component:AdminDashBoardComponent},
  {path:'**',component:PageNotFoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
