import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { SimpleInterestCalculatorComponent } from './simple-interest-calculator/simple-interest-calculator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BankApplicantComponent } from './bank-applicant/bank-applicant.component';
import { SquarePipe } from './square.pipe';
import { SquarerootPipe } from './squareroot.pipe';
import { SiPipe } from './si.pipe';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import { FlowersModule } from './flowers/flowers.module';
import { BirdsModule } from './birds/birds.module';
import { AnimalsModule } from './animals/animals.module';
import { HttpClientModule} from '@angular/common/http';
import { UserDetailsComponent } from './user-details/user-details.component';
import { SingleUserDetailsComponent } from './single-user-details/single-user-details.component';
import { AddUserDetailsComponent } from './add-user-details/add-user-details.component';
import { UpdateUserDetailsComponent } from './update-user-details/update-user-details.component';
import { DeleteUserDetailsComponent } from './delete-user-details/delete-user-details.component';
import { UserPhotoUploadComponent } from './user-photo-upload/user-photo-upload.component';
import { DepartmentComponent } from './department/department.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { RegisterComponent } from './register/register.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutComponent } from './about/about.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { LoginMeComponent } from './login-me/login-me.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';


import {MatIconModule} from '@angular/material/icon';

import {MatSidenavModule} from '@angular/material/sidenav';

import { DetailsComponent } from './details/details.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatRadioModule} from '@angular/material/radio';
import { TestComponent } from './test/test.component';
import { Test2Component } from './test2/test2.component';
import { Test3Component } from './test3/test3.component';
import { MatNativeDateModule } from '@angular/material/core';



@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    SimpleInterestCalculatorComponent,
    BankApplicantComponent,
    SquarePipe,
    SquarerootPipe,
    SiPipe,
    CurrencyConverterComponent,
    UserDetailsComponent,
    SingleUserDetailsComponent,
    AddUserDetailsComponent,
    UpdateUserDetailsComponent,
    DeleteUserDetailsComponent,
    UserPhotoUploadComponent,
    DepartmentComponent,
    OurCompanyComponent,
    RegisterComponent,
    DashBoardComponent,
    PageNotFoundComponent,
    AboutComponent,
    OurEmployeesComponent,
    LoginMeComponent,
    AdminDashBoardComponent,
    ApplicantComponent,
    DetailsComponent,
    TestComponent,
    Test2Component,
    Test3Component,
    

    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    FlowersModule,
    BirdsModule,
    AnimalsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatTabsModule,
    MatButtonModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatSliderModule,
    MatInputModule,
    MatCardModule,
    MatIconModule,
    MatSidenavModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatNativeDateModule,
   
    
    
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
