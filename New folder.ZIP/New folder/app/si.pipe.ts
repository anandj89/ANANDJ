import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'si'
})
export class SiPipe implements PipeTransform {

  transform(principal: number, year: number, rate: number): number {
    return (principal*year*rate*.01);
  }

}
