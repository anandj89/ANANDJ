import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleInterestCalculatorComponent } from './simple-interest-calculator.component';

describe('SimpleInterestCalculatorComponent', () => {
  let component: SimpleInterestCalculatorComponent;
  let fixture: ComponentFixture<SimpleInterestCalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimpleInterestCalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleInterestCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
