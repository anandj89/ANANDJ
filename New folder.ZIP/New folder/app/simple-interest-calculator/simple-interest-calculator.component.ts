import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'si-calc',
  templateUrl: './simple-interest-calculator.component.html',
  styleUrls: ['./simple-interest-calculator.component.css']
})
export class SimpleInterestCalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  principal: number=60000;
  numberOfYears: number=5;
  rateOfInterest: number=6;
  simpleInterest: number=(this.principal*this.numberOfYears*this.rateOfInterest)/100;

  calculateSimpleInterest(){
    console.log('Principal: ',this.principal);
    console.log('No of Years: ',this.numberOfYears);
    console.log('Rate: ',this.rateOfInterest);
    this.simpleInterest=(this.principal*this.numberOfYears*this.rateOfInterest)/100;
    console.log('SI: ',this.simpleInterest);
  }
}
