import { Component, OnInit } from '@angular/core';
import { UserPhotoUploadService } from '../user-photo-upload.service';
import { UserPhoto } from './UserPhotoUpload';

@Component({
  selector: 'app-user-photo-upload',
  templateUrl: './user-photo-upload.component.html',
  styleUrls: ['./user-photo-upload.component.css']
})
export class UserPhotoUploadComponent implements OnInit {
  

  constructor(private ups : UserPhotoUploadService) { }
  userPhoto: UserPhoto[]= [];

  ngOnInit(): void {

    this.ups.loadAllUserPhotoService().subscribe(
      (data)=> {
          this.userPhoto = data;
          console.log(this.userPhoto);
      },
      (err)=> {
        console.log(err);
      }
    );
  }


}
