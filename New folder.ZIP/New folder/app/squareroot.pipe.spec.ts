import { SquarerootPipe } from './squareroot.pipe';

describe('SquarerootPipe', () => {
  it('create an instance', () => {
    const pipe = new SquarerootPipe();
    expect(pipe).toBeTruthy();
  });
});
