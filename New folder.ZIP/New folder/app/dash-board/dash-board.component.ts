import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../login-me/User';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {
  userObj:User=new User();
  anyObject:any;
  constructor(private router:Router) { }

  ngOnInit(): void {
    this.anyObject=sessionStorage.getItem("x");
    this.userObj=JSON.parse(this.anyObject);
  }
  logOutThisUser(){
    this.router.navigate(['/login'])
  }

}
