import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lion',
  templateUrl: './lion.component.html',
  styleUrls: ['./lion.component.css']
})
export class LionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
