export class Mobile{
    mobile!:string;
   
}