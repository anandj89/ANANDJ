import { Component, OnInit } from '@angular/core';
import { Mobile } from './Mobile';

@Component({
  selector: 'app-dog',
  templateUrl: './dog.component.html',
  styleUrls: ['./dog.component.css']
})
export class DogComponent implements OnInit {

  constructor(private mobile:Mobile) { }

  ngOnInit(): void {
    
  }

}
