import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LionComponent } from './lion/lion.component';
import { CatComponent } from './cat/cat.component';
import { DogComponent } from './dog/dog.component';



@NgModule({
  declarations: [
    LionComponent,
    CatComponent,
    DogComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    LionComponent,
    DogComponent,
    CatComponent
  ]
})
export class AnimalsModule { }
