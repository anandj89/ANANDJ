import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parrot',
  templateUrl: './parrot.component.html',
  styleUrls: ['./parrot.component.css']
})
export class ParrotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
