import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crow',
  templateUrl: './crow.component.html',
  styleUrls: ['./crow.component.css']
})
export class CrowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
