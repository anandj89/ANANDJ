export class BankApplicant
{
    applicantId!:number;
    applicantName! : string;
    applicantMobile!: string;
    birthDate!:Date;
    emailAddress!: string;
    permAddress!: string;
    accountAppliedFor!: string;
    panCard!: string;
    annualIncome!: number;
    applicantStatus!: string;
}