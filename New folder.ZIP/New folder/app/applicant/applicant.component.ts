import { Component, OnInit } from '@angular/core';
import { ApplicantService } from '../applicant.service';
import { Applicant } from './Applicant';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {
  message!: string;

  constructor(private applicantService:ApplicantService) { }

  applObj:Applicant=new Applicant();
  appl:Applicant[]=[];

  ngOnInit(): void {

  }
  
    
  addnewAppl() {
    this.applicantService.addApplicant(this.applObj).subscribe({
      next:(data:string) => {
        console.log('applicant is added');
        this.appl.push(this.applObj);
        this.message=data;
        
      },
      error:(err) => {
        
        
        alert(err);
        this.message=err.error;
        console.log(err);
        //alert(this.message);
      },
      complete:()=>{
        console.log('completed)');
      }
  });
  }
  }


